const demoScenarios = {
  image: {
    command: "Изображение",
    bubbles: [
      { type: "user", text: "Киберпанк-портрет в неоновом свете, детальная кожа, cinematic lighting." },
      { type: "bot", text: "Готовлю изображение. Выберите стиль, формат и модель. Результат появится в истории." },
      { type: "result", text: "Готово: можно сохранить, улучшить промпт, повторить генерацию или отправить работу в ленту." },
    ],
  },
  video: {
    command: "Видео",
    bubbles: [
      { type: "user", text: "Короткий ролик: неоновый логотип раскрывается из частиц, камера плавно приближается." },
      { type: "bot", text: "Запускаю генерацию видео. После обработки файл будет доступен в чате и истории." },
      { type: "result", text: "Видео готово. Можно вернуться к нему позже, повторить сценарий или сделать новую версию." },
    ],
  },
  music: {
    command: "Музыка",
    bubbles: [
      { type: "user", text: "Энергичный synthwave-трек для презентации AI-продукта, 30 секунд." },
      { type: "bot", text: "Создаю музыкальный вариант. Можно использовать как основу для Reels, Shorts и промо." },
      { type: "result", text: "Трек готов. Сохранён в истории, чтобы быстро вернуться к нему в следующем проекте." },
    ],
  },
  assistant: {
    command: "/assistant",
    bubbles: [
      { type: "user", text: "Улучши промпт для фэшн-кадра в неоновом свете." },
      { type: "bot", text: "Добавь объект, камеру, материал, свет и запреты. Например: editorial fashion portrait, wet asphalt reflections, cyan-magenta rim light, 85mm, clean skin texture." },
      { type: "result", text: "Промпт готов к запуску в Фото или Midjourney. При необходимости проверю модерационные риски." },
    ],
  },
}

const navToggle = document.querySelector(".nav-toggle")
const siteNav = document.querySelector(".site-nav")

function closeNav() {
  if (!navToggle || !siteNav) return
  siteNav.classList.remove("is-open")
  navToggle.setAttribute("aria-expanded", "false")
}

if (navToggle && siteNav) {
  navToggle.addEventListener("click", () => {
    const isOpen = siteNav.classList.toggle("is-open")
    navToggle.setAttribute("aria-expanded", String(isOpen))
  })

  siteNav.addEventListener("click", (event) => {
    if (event.target instanceof HTMLAnchorElement) closeNav()
  })

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeNav()
  })

  document.addEventListener("click", (event) => {
    if (!siteNav.classList.contains("is-open")) return
    if (event.target instanceof Node && !siteNav.contains(event.target) && !navToggle.contains(event.target)) {
      closeNav()
    }
  })
}

const chatStream = document.getElementById("chat-stream")
const demoCommand = document.getElementById("demo-command")
const demoButtons = Array.from(document.querySelectorAll("[data-demo]"))
const rerunDemo = document.querySelector("[data-rerun-demo]")
let activeDemo = "image"

function renderDemo(key = activeDemo) {
  if (!chatStream || !demoScenarios[key]) return
  activeDemo = key
  const scenario = demoScenarios[key]
  chatStream.innerHTML = ""
  if (demoCommand) demoCommand.textContent = scenario.command
  demoButtons.forEach((button) => button.classList.toggle("is-active", button.dataset.demo === key))

  scenario.bubbles.forEach((bubble, index) => {
    window.setTimeout(() => {
      const node = document.createElement("div")
      node.className = `bubble ${bubble.type}`
      node.textContent = bubble.text
      chatStream.appendChild(node)
    }, index * 240)
  })
}

demoButtons.forEach((button) => {
  button.addEventListener("click", () => renderDemo(button.dataset.demo))
})

if (rerunDemo) {
  rerunDemo.addEventListener("click", () => renderDemo(activeDemo))
}

renderDemo("image")

const commandCards = Array.from(document.querySelectorAll(".command-card"))
const commandResponse = document.getElementById("command-response")
const copyToast = document.getElementById("copy-toast")
let copyToastTimer

async function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(text)
    return
  }
  const textarea = document.createElement("textarea")
  textarea.value = text
  textarea.style.position = "fixed"
  textarea.style.opacity = "0"
  document.body.appendChild(textarea)
  textarea.select()
  document.execCommand("copy")
  textarea.remove()
}

function showToast(message) {
  if (!copyToast) return
  copyToast.textContent = message
  copyToast.classList.add("is-visible")
  window.clearTimeout(copyToastTimer)
  copyToastTimer = window.setTimeout(() => copyToast.classList.remove("is-visible"), 1500)
}

commandCards.forEach((card) => {
  card.addEventListener("click", async () => {
    const command = card.dataset.command || ""
    const response = card.dataset.response || "{}"
    commandCards.forEach((item) => item.classList.toggle("is-active", item === card))
    if (commandResponse) {
      try {
        commandResponse.textContent = JSON.stringify({ command, ...JSON.parse(response) }, null, 2)
      } catch {
        commandResponse.textContent = response
      }
    }
    try {
      if (command) await copyText(command)
      showToast(command ? "Команда скопирована" : "Сценарий открыт")
    } catch {
      showToast("Не удалось скопировать")
    }
  })
})

const accordionItems = Array.from(document.querySelectorAll(".faq-item"))

accordionItems.forEach((item, index) => {
  const button = item.querySelector("button")
  item.classList.toggle("is-open", index === 0)
  if (!button) return
  button.addEventListener("click", () => {
    const nextState = !item.classList.contains("is-open")
    accordionItems.forEach((entry) => {
      entry.classList.remove("is-open")
      const entryButton = entry.querySelector("button")
      if (entryButton) entryButton.setAttribute("aria-expanded", "false")
    })
    item.classList.toggle("is-open", nextState)
    button.setAttribute("aria-expanded", String(nextState))
  })
})

const contactForm = document.getElementById("contact-form")
const formStatus = document.getElementById("form-status")

function setError(field, message) {
  const wrapper = field.closest("div")
  const error = wrapper ? wrapper.querySelector(".field-error") : null
  if (error) error.textContent = message
}

function validateContactForm(form) {
  let valid = true
  const name = form.elements.name
  const contact = form.elements.contact
  const message = form.elements.message

  setError(name, "")
  setError(contact, "")
  setError(message, "")

  if (!name.value.trim() || name.value.trim().length < 2) {
    setError(name, "Напишите имя хотя бы из двух символов.")
    valid = false
  }

  const contactValue = contact.value.trim()
  const looksLikeTelegram = /^@[a-zA-Z0-9_]{5,}$/.test(contactValue)
  const looksLikeEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(contactValue)
  if (!looksLikeTelegram && !looksLikeEmail) {
    setError(contact, "Укажите Telegram в формате @username или email.")
    valid = false
  }

  if (!message.value.trim() || message.value.trim().length < 20) {
    setError(message, "Добавьте детали: модель, время, что ожидали получить.")
    valid = false
  }

  return valid
}

if (contactForm) {
  contactForm.addEventListener("submit", (event) => {
    event.preventDefault()
    if (!validateContactForm(contactForm)) {
      if (formStatus) formStatus.textContent = ""
      return
    }
    if (formStatus) {
      formStatus.textContent = "Спасибо! Сообщение подготовлено. Мы свяжемся с вами через указанные контакты."
    }
    contactForm.reset()
  })
}
